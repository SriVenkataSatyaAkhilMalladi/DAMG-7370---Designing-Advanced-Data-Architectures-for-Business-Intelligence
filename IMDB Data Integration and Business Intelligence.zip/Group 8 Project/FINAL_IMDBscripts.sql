-- TREND ANALYSIS
select release_year, avg(runtime)
from Movie_Performance_FACT
group by 1;

select release_year, avg(avg_rating)
from Movie_Performance_FACT
group by 1;

select release_year, count(distinct movie_dim_fk)
from Movie_Performance_FACT
group by 1;

-- GENRE ANALYSIS
select genre, avg(avg_rating) 
from Movie_Performance_FACT mp
join Movie_DIM m on m.movie_sk = mp.movie_dim_fk
join Genre_Movie_BRIDGE gb on gb.movie_dim_fk = m.movie_dim_fk
join Genre_DIM g on g.genre_sk = gb.genre_fk
group by 1;

select genre, sum(total_gross_revenue) 
from Movie_Performance_FACT mp
join Movie_DIM m on m.movie_sk = mp.movie_dim_fk
join Genre_Movie_BRIDGE gb on gb.movie_dim_fk = m.movie_dim_fk
join Genre_DIM g on g.genre_sk = gb.genre_fk
group by 1;

-- PERFORMANCE METRICS
select runtime, avg_rating
from Movie_Performance_FACT;

select runtime, total_gross_revenue
from Movie_Performance_FACT;

select num_votes, avg_rating
from Movie_Performance_FACT;

-- DIRECTOR SUCCESS METRICS
select p.name, count(distinct movie_dim_fk)
from Movie_Performance_FACT mp
join Movie_DIM m on m.movie_sk = mp.movie_dim_fk
join Directors_DIM d on d.movie_dim_fk = m.movie_sk
join Person_DIM p on p.person_dk = d.person_dim_fk
where avg_rating > 7
group by 1
;

select p.name, count(distinct movie_dim_fk), sum(total_gross_revenue)
from Movie_Performance_FACT mp
join Movie_DIM m on m.movie_sk = mp.movie_dim_fk
join Directors_DIM d on d.movie_dim_fk = m.movie_sk
join Person_DIM p on p.person_dk = d.person_dim_fk
group by 1
;

-- ACTOR AND ACTRESS FILM RECORDS
select p.name, count(distinct movie_dim_fk)
from Movie_Performance_FACT mp
join Movie_DIM m on m.movie_sk = mp.movie_dim_fk
join Actors_DIM a on a.movie_dim_fk = m.movie_sk
join Person_DIM p on p.person_dk = d.person_dim_fk
where mp.avg_rating >= 4 and mp.avg_rating <= 7
group by 1
order by count(distinct movie_dim_fk) desc
limit 10;

-- ACTOR AND ACTRESS FILM RECORDS
select p.name, avg(avg_rating)
from Movie_Performance_FACT mp
join Movie_DIM m on m.movie_sk = mp.movie_dim_fk
join Actors_DIM a on a.movie_dim_fk = m.movie_sk
join Person_DIM p on p.person_dk = d.person_dim_fk
group by 1
order by avg(avg_rating) desc
limit 5;

-- SEASON ANALYSIS
select year, season, sum(daily_gross_revenue) 
from Movie_Daily_Revenue_FACT md
join Date_DIM d on d.date_sk = md.date_fk
group by 1, 2
order by sum(daily_gross_revenue) desc;    

WITH RankedMovies AS (
  SELECT
    season,
    title,
    SUM(daily_gross_revenue) AS total_gross,
    RANK() OVER (PARTITION BY season ORDER BY SUM(daily_gross_revenue) DESC) AS season_rank
  FROM
    Movie_Daily_Revenue_FACT md
    JOIN Date_DIM d ON d.date_sk = md.date_fk
    JOIN Movie_Performance_FACT mp ON mp.movie_performance_sk = md.movie_performance_fk
    JOIN Movie_DIM m ON m.movie_sk = mp.movie_dim_fk
  GROUP BY 1, 2
)
SELECT
  season,
  title,
  total_gross,
  season_rank
FROM
  RankedMovies
WHERE
  season_rank < 4
ORDER BY
  season,
  season_rank;

-- RELEASE REGIONS
select tconstant_nk, title, count(distinct region_fk)
from Region_Movie_BRIDGE rm
join Movie_DIM m on m.movie_sk = rm.movie_dim_fk 
group by 1, 2;

select title, 
count(distinct d.person_dim_fk) as cnt_dir,
count(distinct a.person_dim_fk) as cnt_actors,
count(distinct w.person_dim_fk) ascnt_writers,
max(total_gross_revenue) as worldwide_earnings,
max(avg_rating) as avg_rating,
count(distinct r.region) as cnt_region,
count(distinct g.genre) as cnt_genre

from Movie_DIM m 
join Movie_Performance_FACT mp on m.movie_sk = mp.movie_dim_fk

join Genre_Movie_BRIDGE gb on gb.movie_dim_fk = m.movie_dim_fk
join Genre_DIM g on g.genre_sk = gb.genre_fk

join Region_Movie_BRIDGE rm on m.movie_sk = rm.movie_dim_fk 
join Region_DIM r on r.region_sk = rm.region_fk

join Directors_DIM d on d.movie_dim_fk = m.movie_sk

join Writers_DIM w on w.movie_dim_fk = m.movie_sk

join Actors_DIM a on a.movie_dim_fk = m.movie_sk

where total_gross_revenue > 1
group by 1;


