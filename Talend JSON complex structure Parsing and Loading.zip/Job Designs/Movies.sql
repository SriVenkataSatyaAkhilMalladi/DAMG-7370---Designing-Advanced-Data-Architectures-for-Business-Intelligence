CREATE DATABASE Movies;
Use Movies;
DROP TABLE IF EXISTS MovieCategories;
DROP TABLE IF EXISTS MovieWriters;
DROP TABLE IF EXISTS MovieActors;
DROP TABLE IF EXISTS MovieDetails;
DROP TABLE IF EXISTS Directors;
DROP TABLE IF EXISTS actors;


CREATE TABLE actors (
    birthdate VARCHAR(500),
    birthname VARCHAR(500),
    birthplace VARCHAR(500),
    name VARCHAR(500) PRIMARY KEY
);

CREATE TABLE Directors (
    birthdate VARCHAR(500),
    birthname VARCHAR(500),
    birthplace VARCHAR(500),
    name VARCHAR(500) PRIMARY KEY
);


CREATE TABLE MovieDetails (
    director VARCHAR(200),
    Filepath VARCHAR(200),
    jobid VARCHAR(200),
    name VARCHAR(200) PRIMARY KEY,
    releasedate VARCHAR(200),
    runtime VARCHAR(200),
    sk INT,
    storyline VARCHAR(4000),
    year VARCHAR(200),
    Category VARCHAR(200)
);


CREATE TABLE MovieCategories (
    catergoriescsv VARCHAR(200),
    name VARCHAR(200),
    Filepath VARCHAR(200),
    PRIMARY KEY (catergoriescsv, name),
    FOREIGN KEY (name) REFERENCES MovieDetails(name)
);
CREATE TABLE  MovieActors (
    actorcsv VARCHAR(200),
    name VARCHAR(200),
    Filepath VARCHAR(200),
    PRIMARY KEY (actorcsv, name),
    FOREIGN KEY (actorcsv) REFERENCES actors(name),
    FOREIGN KEY (name) REFERENCES MovieDetails(name)
);

CREATE TABLE MovieWriters (
    writercsv VARCHAR(200),
    name VARCHAR(200),
    Filepath VARCHAR(200),
    PRIMARY KEY (writercsv, name),
    FOREIGN KEY (name) REFERENCES MovieDetails(name)
);

Select * from MovieDetails where name = 'The Lost World: Jurassic Park';
select count(*) from MovieActors where name = 'The Magnificent Seven';
select count(*) from MovieWriters where name = '2 Fast 2 Furious';

select count(*) from Actors;
select count(*) from Directors;
select * from MovieWriters where writercsv = 'Greg Taylor';

ALTER TABLE MovieActors
ADD CONSTRAINT fk_MovieDetails_name2
FOREIGN KEY (name) REFERENCES MovieDetails(name);


ALTER TABLE MovieWriters
ADD CONSTRAINT fk_MovieDetails_name3
FOREIGN KEY (name) REFERENCES MovieDetails(name);

SELECT 
    md.Category, 
    md.name AS MovieName, 
    (SELECT COUNT(*) FROM MovieActors ma WHERE ma.name = md.name) AS ActorCount,
    (SELECT COUNT(*) FROM MovieWriters mw WHERE mw.name = md.name) AS WriterCount
FROM 
    MovieDetails md
WHERE 
    (SELECT COUNT(*) FROM MovieActors ma WHERE ma.name = md.name) > 3
    AND (SELECT COUNT(*) FROM MovieWriters mw WHERE mw.name = md.name) > 4
    AND (SELECT COUNT(*) FROM MovieDetails mw WHERE mw.name = md.name) < 2;

SELECT year, name AS MovieTitle
FROM MovieDetails
ORDER BY year, name;


