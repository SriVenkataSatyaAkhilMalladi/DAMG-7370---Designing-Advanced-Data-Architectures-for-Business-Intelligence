CREATE TABLE [staging_food_inspection] (
  [BusinessID] varchar(12) NOT NULL,
  [Name] varchar(69) NULL,
  [Address] varchar(32) NULL,
  [City] varchar(17) NULL,
  [State] varchar(2) NULL,
  [ZipCode] varchar(10) NULL,
  [PhoneNumber] varchar(12) NULL,
  [InspectionId] varchar(9) NULL,
  [Date] date NULL,
  [InspectionType] varchar(9) NULL,
  [ViolationCodes] varchar(109) NULL,
  [ViolationDescription] varchar(254) NULL,
  [Location] varchar(86) NULL,
  [DI_CreatedDate] date NULL,
  [DI_JobID] varchar(255) NULL,
  [DI_WorkflowFileName] varchar(255) NULL,
  PRIMARY KEY CLUSTERED ([BusinessID])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO

