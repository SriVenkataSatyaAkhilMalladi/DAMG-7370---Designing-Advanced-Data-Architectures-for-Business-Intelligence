CREATE TABLE [midterm].[business_DIM] (
  [business_sk] int NOT NULL,
  [business_id_nk] varchar(20) NOT NULL,
  [business_name] varchar(85) NOT NULL,
  [full_address_string] varchar(500) NOT NULL,
  [city] varchar(30) NOT NULL,
  [state] varchar(30) NOT NULL,
  [zipcode] varchar(30) NOT NULL,
  [phone_number] varchar(15) NOT NULL,
  [lat] float NOT NULL,
  [long] float NOT NULL,
  [DI_JobID] varchar(255) NOT NULL,
  [DI_CreatedDate] date NOT NULL,
  [DI_WorkflowFileName] varchar(255) NOT NULL,
  CONSTRAINT [_copy_5] PRIMARY KEY CLUSTERED ([business_sk])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO

CREATE TABLE [midterm].[date_DIM] (
  [date_sk] int NOT NULL,
  [date] date NOT NULL,
  [day_str] varchar(255) NOT NULL,
  [year] int NOT NULL,
  [quarter] varchar(255) NOT NULL,
  [month] int NOT NULL,
  [month_str] varchar(255) NOT NULL,
  [isWeekend] char(1) NOT NULL,
  [isWeekday] char(1) NOT NULL,
  [DI_JobID] varchar(255) NOT NULL,
  [DI_CreatedDate] date NOT NULL,
  [DI_WorkflowFileName] varchar(255) NOT NULL,
  CONSTRAINT [_copy_4] PRIMARY KEY CLUSTERED ([date_sk])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO

CREATE TABLE [midterm].[inspection_FACT] (
  [inspection_sk] int NOT NULL,
  [inspection_nk_id] varchar(9) NOT NULL,
  [inspection type] varchar(9) NOT NULL,
  [inspection_result] varchar(4) NOT NULL,
  [inspection_score] int NOT NULL,
  [DI_JobID] varchar(255) NOT NULL,
  [DI_CreatedDate] date NOT NULL,
  [DI_WorkflowFileName] varchar(255) NOT NULL,
  CONSTRAINT [_copy_1] PRIMARY KEY CLUSTERED ([inspection_sk])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO

CREATE TABLE [midterm].[violation_DIM] (
  [violation_sk] int NOT NULL,
  [violation_code] varchar(500) NOT NULL,
  [violation_description] varchar(5000) NOT NULL,
  [violation_category] varchar(500) NOT NULL,
  [DI_JobID] varchar(255) NOT NULL,
  [DI_CreatedDate] date NOT NULL,
  [DI_WorkflowFileName] varchar(255) NOT NULL,
  [violation_score] int NOT NULL,
  CONSTRAINT [_copy_3] PRIMARY KEY CLUSTERED ([violation_sk])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO

CREATE TABLE [midterm].[violation_inspection_FACT] (
  [inspection_violation_sk] int NOT NULL,
  [business_DIM_fk] int NOT NULL,
  [date_DIM_fk] int NOT NULL,
  [violation_DIM_fk] int NOT NULL,
  [individual_violation_score] int NOT NULL,
  [inspection_FACT_fk] int NOT NULL,
  [DI_JobID] varchar(255) NOT NULL,
  [DI_CreatedDate] date NOT NULL,
  [DI_WorkflowFileName] varchar(255) NOT NULL,
  CONSTRAINT [_copy_9] PRIMARY KEY CLUSTERED ([inspection_violation_sk])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO

ALTER TABLE [midterm].[violation_inspection_FACT] ADD CONSTRAINT [business_DIM_fk] FOREIGN KEY ([business_DIM_fk]) REFERENCES [midterm].[business_DIM] ([business_sk])
GO
ALTER TABLE [midterm].[violation_inspection_FACT] ADD CONSTRAINT [violation_DIM_fk] FOREIGN KEY ([violation_DIM_fk]) REFERENCES [midterm].[violation_DIM] ([violation_sk])
GO
ALTER TABLE [midterm].[violation_inspection_FACT] ADD CONSTRAINT [date_DIM_fk] FOREIGN KEY ([date_DIM_fk]) REFERENCES [midterm].[date_DIM] ([date_sk])
GO
ALTER TABLE [midterm].[violation_inspection_FACT] ADD CONSTRAINT [inspection_FACT_fk] FOREIGN KEY ([inspection_FACT_fk]) REFERENCES [midterm].[inspection_FACT] ([inspection_sk])
GO

