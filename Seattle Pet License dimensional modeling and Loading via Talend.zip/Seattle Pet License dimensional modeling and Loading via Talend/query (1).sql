use  dadabi;
Select * from seattle_breed;
DROP TABLE seattle_location;
Select * from seattle_stg;
Select * from seattle_breed_dim;
Select * from seattle_location_dim;
Select * from seattle_date_dim;
Select * from seattle_Fact ;
SELECT COLUMN_NAME, DATA_TYPE, CHARACTER_MAXIMUM_LENGTH 
FROM information_schema.COLUMNS 
WHERE TABLE_SCHEMA = 'dadabi' AND TABLE_NAME = 'seattle_date_dim';



SELECT *
FROM seattle_Fact AS SF
LEFT JOIN seattle_date_dim AS SD ON SF.date_sk = SD.date_sk
WHERE SD.date_sk = 20190127;



SELECT CHARACTER_MAXIMUM_LENGTH FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = 'Database' AND TABLE_NAME = 'Table' AND COLUMN_NAME = 'Field';