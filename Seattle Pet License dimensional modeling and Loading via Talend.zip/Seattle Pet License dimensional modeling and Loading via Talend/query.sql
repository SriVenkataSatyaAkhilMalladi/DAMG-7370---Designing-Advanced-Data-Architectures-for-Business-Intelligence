-- Drop tables if they exist
DROP TABLE seattle_Fact;
DROP TABLE seattle_date_dim;
DROP TABLE seattle_location_dim;
DROP TABLE seattle_breed_dim;

-- Create seattle_breed_dim table
CREATE TABLE seattle_breed_dim (
    BreedSK INT PRIMARY KEY,
    DI_CreatedDate DATETIME NULL,
    DI_ProcessID VARCHAR(50),
    Primary_Breed VARCHAR(50),
    Secondary_Breed VARCHAR(50),
    Species VARCHAR(5)
);

-- Create seattle_location_dim table
CREATE TABLE seattle_location_dim (
    city VARCHAR(50),
    DI_CreatedDate DATETIME NULL,
    DI_ProcessID VARCHAR(50),
    LocationSK INT PRIMARY KEY,
    State VARCHAR(20),
    State_abbr VARCHAR(5),
    zipcode VARCHAR(10)
);

-- Create seattle_date_dim table
CREATE TABLE seattle_date_dim (
    date DATETIME NULL,
    date_sk INT PRIMARY KEY,
    day_str VARCHAR(50),
    dayNum INT,
    DI_CreatedDate DATETIME NULL,
    isWeekday CHAR(50),
    isWeekend CHAR(50),
    month_str VARCHAR(50),
    monthNum INT,
    newColumn1 VARCHAR(50),
    qtr VARCHAR(50),
    Year INT
);

-- Create seattle_Fact table
CREATE TABLE seattle_Fact (
    seattle_Fact_sk INT PRIMARY KEY,
    Location_sk INT,
    License_Number VARCHAR(50),
    License_issue_date DATETIME NULL,
    DI_ProcessID VARCHAR(50),
    DI_CreatedDate DATETIME NULL,
    date_sk INT,
    Breed_sk INT,
    Animal_Name VARCHAR(50),
    Animal_count INT,
    FOREIGN KEY (Location_sk) REFERENCES seattle_location_dim(LocationSK),
    FOREIGN KEY (date_sk) REFERENCES seattle_date_dim(date_sk),
    FOREIGN KEY (Breed_sk) REFERENCES seattle_breed_dim(BreedSK)
);
